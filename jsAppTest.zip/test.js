loggedin = false;
password = "";
do {
password = prompt("Zhe Zectret Vword:");
} while(password != "zurprise")

alert('Welcome, Admin');

